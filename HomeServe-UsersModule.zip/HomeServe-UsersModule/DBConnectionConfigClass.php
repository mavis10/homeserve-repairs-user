<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DBConnectionClass
 *
 * @author MadhAvi
 */
class DBConnectionConfigClass extends PDO {

    protected $dsn;
    protected $userName;
    protected $password;
    protected $connection;
    

    public function __construct() {
        $this->userName = "root";
        $this->password = "";
        $this->dsn = 'mysql:dbname=homeserverepair;host=127.0.0.1';   
    }

    /**
     * 
     * @return type connection
     */
    public function connect() {
        try {
            $this->connection = new PDO($this->dsn, $this->userName, $this->password);
            return $this->connection;
        } catch (PDOException $e) {
            echo 'Connection failed: ' . $e->getMessage();
        }
    }
}
