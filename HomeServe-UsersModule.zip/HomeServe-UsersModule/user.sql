-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2020 at 10:07 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `homeserverepair`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userID` int(10) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `access` enum('ACTIVE','INACTIVE','','') NOT NULL DEFAULT 'INACTIVE',
  `createdAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `userName`, `password`, `firstName`, `lastName`, `email`, `access`, `createdAt`) VALUES
(1, 'testuser1', '$2y$10$FJx2aaQUZGOSJTaWLK4CPOs128TjJMxedDWW466xP2n.', 'Test1', 'User1', 'testUser1@test.com', 'ACTIVE', '2020-09-29 15:23:36'),
(2, 'testuser2', '$2y$10$FJx2aaQUZGOSJTaWLK4CPOs128TjJMxedDWW466xP2n.', 'Test2', 'User2', 'testUser2@test.com', 'ACTIVE', '2020-09-29 15:24:36'),
(3, 'testuser3', '$2y$10$FJx2aaQUZGOSJTaWLK4CPOs128TjJMxedDWW466xP2n22.yypL2Re', 'Test3', 'User3', 'testUser3@test.com', 'ACTIVE', '2020-09-30 13:38:19'),
(4, 'testuser4', '$2y$10$iTg5HTy5EGz5vbs5sMCvYOzzMZ.zhMgMphZDHIdc9DVmURMUQ97c6', 'Test4', 'User4', 'testuser4@test.com', 'ACTIVE', '2020-09-30 22:41:37'),
(5, 'testuser5', '$2y$10$7bbB0yHhKrhymZ1sJFkvyO1HIVEczT5fOkltcM40DcSOUUob6YgS.', 'Test5', 'User5', 'testuser5@test.com', 'ACTIVE', '2020-10-01 10:04:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
