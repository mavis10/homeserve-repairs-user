<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="/lib/bootstrap-3.4.1-dist/css/bootstrap.min.css" >
        <link rel="stylesheet" href="/lib/bootstrap-3.4.1-dist/css/bootstrap-theme.min.css" >
        <link rel="stylesheet" href="user/parsleyErrorCss.css">
        <script src="/lib/jquery-3.5.1.min.js"></script>
        <script src="/lib/bootstrap-3.4.1-dist/js/bootstrap.min.js"></script>
        <script src="/lib/parsley.min.js"></script>
        <script src="user/user.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <h2 align='center'>Users</h2>
                <div id="messageDiv"></div>
                <table class="table" id="userTable" border='1'>
                    <thead>
                        <tr>
                            <th align='center'>User ID</th>
                            <th align='center'>User Name</th>
                            <th align='center'>First Name</th>
                            <th align='center'>Last Name</th>
                            <th align='center'>Email</th>
                            <th align='center'>Access</th>
                            <th align='center'>Created At</th>
                            <th align='center'>Action</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>

                <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#userModal">Create New User</button>

            </div>

            <!--- USer Modal -->
            <div class="modal fade" id="userModal" role="dialog">
                <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">Add New User</h4>
                        </div>
                        <div class="modal-body">
                            <form id="userForm" data-parsley-validate="">
                                <div class="form-group row">
                                    <label for="firstName" class="col-sm-3 col-form-label">First Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="inputFirstName" placeholder="First Name" data-parsley-required="true">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="lastName" class="col-sm-3 col-form-label">Last Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="inputLastName" placeholder="Last Name" data-parsley-required="true">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputEmail" class="col-sm-3 col-form-label">Email</label>
                                    <div class="col-sm-8">
                                        <input type="email" class="form-control" id="inputEmail" placeholder="Email" data-parsley-type="email"  data-parsley-required="true" >
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="userName" class="col-sm-3 col-form-label">User Name</label>
                                    <div class="col-sm-8">
                                        <input type="text" data-parsley-type="alphanum" class="form-control" id="inputUserName" placeholder="User Name" 
                                               data-parsley-required="true" data-parsley-minlength="7" data-parsley-minlength-message="User Name must be at least 7 characters">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputPassword" class="col-sm-3 col-form-label">Password</label>
                                    <div class="col-sm-8">
                                        <input type="password" class="form-control" id="inputPassword" placeholder="Password" data-parsley-required="true" 
                                               data-parsley-minlength="7" 
                                               d                                               data-parsley-minlength-message="Password must be at least 7 characters">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="inputConfirmPassword" class="col-sm-3 col-form-label">Confirm Password</label>
                                    <div class="col-sm-8">
                                        <input type="password" class="form-control" id="inputConfirmPassword" placeholder="Confirm Password" 
                                               data-parsley-equalto="#inputPassword" data-parsley-equalto-message="This Field should be similar to Password">
                                    </div>
                                </div>
                                <div id="formErrorDiv" class='alert alert-danger' role='alert' style="display: none"></div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" id='btnAddNewUser'>Add</button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal" id='btnCloseUserModal'>Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
