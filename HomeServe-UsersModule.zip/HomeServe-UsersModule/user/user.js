$(document).ready(function () {

    /**
     * load all user when document is ready
     */
    loadUserTable();

    /**
     * Update user Access
     *  
     */
    $("#userTable").on('click', 'button.btnChangeUserAccess', function () {
        $.ajax('/user/userController.php', // request url
                {
                    type: "POST",
                    dataType: 'json', // type of response data
                    data: {action: "updateAccess", userID: $(this).attr("data-userid")}, // data to submit
                    success: function (response, status, xhr) {// success callback function
                        $("div#messageDiv").empty();

                        //If response is a Success show SUCCESS message otherwise show ERROR message
                        if (response.status === "SUCCESS")
                        {
                            //Refresh User table data
                            refreshsUserTable(response.data);
                            $("#messageDiv").html("<div class='alert alert-success' role='alert'>" + response.message + "</div>");

                        } else
                        {
                            $("#messageDiv").html("<div class='alert alert-warning' role='alert'>ERROR:" + response.message + "</div>");
                        }
                    },
                    error: function (jqXhr, textStatus, errorMessage) { // error callback
                        $('p').append('Error: ' + errorMessage);
                    }
                });

    });

    /**
     * reset form
     */
    $("#btnCloseUserModal").click(function () {
        $('#userForm')[0].reset();
    });


    /**
     * Add new user in system
     */

    $("#btnAddNewUser").click(function () {
        var userForm = $('#userForm').parsley();
        userForm.validate();

        if (userForm.isValid())
        {
            $.ajax('/user/userController.php', // request url
                    {
                        type: "POST",
                        dataType: 'json', // type of response data
                        data: {action: "addNewUser", firstName: $("#inputFirstName").val(), lastName: $("#inputLastName").val(), email: $("#inputEmail").val(), userName: $("#inputUserName").val(), password: $("#inputPassword").val()},
                        success: function (response, status, xhr) {// success callback function
                            $("div#messageDiv").empty();
                            $("div#formErrorDiv").empty();

                            //If response is a Success show SUCCESS message otherwise show ERROR message
                            if (response.status === "SUCCESS")
                            {
                                //Refresh User table data
                                refreshsUserTable(response.data);
                                $('#userModal').modal('hide'); //Hide the modal
                                $('#userForm')[0].reset(); //resets the form
                                $("#messageDiv").html("<div class='alert alert-success' role='alert'>" + response.message + "</div>");

                            } else
                            {
                                //
                                if (response.message.length > 0)
                                {
                                    $("#formErrorDiv").show();

                                    $.each(response.message, function (index, val) {

                                        $("#formErrorDiv.alert").append(val + "<br/>");
                                    });
                                } else
                                {
                                    $("#messageDiv").html("<div class='alert alert-warning' role='alert'>ERROR:" + response.message + "</div>");
                                }
                            }
                        },
                        error: function (jqXhr, textStatus, errorMessage) { // error callback
                            $('p').append('Error: ' + errorMessage);
                        }
                    });
        }
    });


    /**
     * calls ajax function to load all users in sustem
     * @returns {undefined}
     */
    function loadUserTable()
    {
        $.ajax('/user/userController.php', // request url
                {
                    dataType: 'json', // type of response data
                    success: function (response, status, xhr) {// success callback function

                        $("div#messageDiv").empty();

                        if (response.status === "SUCCESS")
                        {
                            refreshsUserTable(response.data);

                        } else
                        {
                            $("#messageDiv").html("<div class='alert alert-warning' role='alert'>Error Occurred!</div>");
                        }


                    },
                    error: function (jqXhr, textStatus, errorMessage) { // error callback
                        $('p').append('Error: ' + errorMessage);
                    }
                });

    }


    /**
     * refreshes the user table data
     * @param {type} data
     * @returns {undefined}
     */
    function refreshsUserTable(data)
    {
        $('#userTable tbody > tr').remove();
        if (data.length > 0)
        {
            $.each(data, function (index, val) {
                var tr_str = "<tr>" +
                        "<td>" + val.userID + "</td>" +
                        "<td>" + val.userName + "</td>" +
                        "<td>" + val.firstName + "</td>" +
                        "<td>" + val.lastName + "</td>" +
                        "<td>" + val.email + "</td>" +
                        "<td>" + val.access + "</td>" +
                        "<td>" + val.createdAt + "</td>" +
                        "<td><button type='button' class='btnChangeUserAccess' data-userid='" + val.userID + "'>" + (val.access === "ACTIVE" ? "Deactivate" : "Activate") + " User</button></td>" +
                        "</tr>";
                $("#userTable tbody").append(tr_str);
            });

        } else
        {
            var tr_str = "<tr><td colspan = '8'>No Users Added </td></tr>";
            $("#userTable tbody").append(tr_str);
        }
    }

});