<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of UserDataClass 
 * 
 * User class handles all Database related activity for user table
 *
 * @author MadhAvi
 */
require('../DBConnectionConfigClass.php');

class UserDataClass {

    protected $PDOObj;

    public function __construct() {
        $dbConnectClass = new DBConnectionConfigClass();
        $this->PDOObj = $dbConnectClass->connect();
    }

    /**
     * Retrieve all users from system
     * @return type array of Objects
     */
    public function readAllUsers() {
        $records = array();
        try {
            $sql = "SELECT `userID`,`userName`,`firstName`,`lastName`,`email`,`access`,`createdAt` FROM `user` ";
            $stmt = $this->PDOObj->prepare($sql);
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_OBJ);
            foreach ($rows as $row) {
                $records[] = [
                    'userID' => $row->userID,
                    'userName' => $row->userName,
                    'firstName' => $row->firstName,
                    'lastName' => $row->lastName,
                    'email' => $row->email,
                    'access' => $row->access,
                    'createdAt' => date('m/d/Y H:i:s', strtotime($row->createdAt))
                ];
            }
        } catch (PDOException $e) {
            //echo $e->getMessage();
        }
        return $records;
    }

    /**
     * Reads user data on user ID
     * @param type $userID
     * @return type array of Objects
     */
    public function readUser($data, $colName) {
        $record = array();
        try {
            $sql = "SELECT `userID`,`userName`,`firstName`,`lastName`,`email`,`access`,`createdAt` FROM `user` WHERE`" . $colName . "` = :" . $colName;
            $stmt = $this->PDOObj->prepare($sql);
            if (is_int($data[$colName])) {
                $stmt->bindValue(':' . $colName, $data[$colName], PDO::PARAM_INT);
            } else if (is_string($data[$colName])) {
                $stmt->bindValue(':' . $colName, $data[$colName], PDO::PARAM_STR);
            }
            $stmt->execute();
            $record = $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            //echo $e->getMessage();
        }

        return $record;
    }

    /**
     * Creates new User in system 
     * @param type $data
     * @return type bool
     */
    public function addUser($data) {

        $response['status'] = 'ERROR';

        $userNameExists = $this->readUser($data, 'userName');
        $emailExists = $this->readUser($data, 'email');

        //Add User If UserName and email are not already exists
        if (!$userNameExists && !$emailExists) {
            try {
                $sql = "INSERT INTO `user` (`firstName`, `lastName`, `email`, `userName`, `password`, `access`, `createdAt`) VALUES (:firstName, :lastName, :email, :userName, :password,DEFAULT,:createdAt)";
                $stmt = $this->PDOObj->prepare($sql);
                $this->bindParams($stmt, $data);
                $stmt->bindValue(':createdAt', date('Y-m-d H:i:s'), PDO::PARAM_STR);
                $record = $stmt->execute();

                if ($record === TRUE) {
                    $response['status'] = 'SUCCESS';
                    $response['message'] = 'Record Added';
                }
            } catch (PDOException $e) {
                $response['message'] = $e->getMessage();
            }
        } else {
            if ($emailExists) {
                $response['message'][] = 'Email already exists.';
            }
            if ($userNameExists) {
                $response['message'][] = 'User Name already exists.';
            }
        }

        return $response;
    }

    /**
     * Updates User data
     * @param type $userID
     * @param type $access
     * @return type bool
     */
    public function updateUser($data) {
        $response['status'] = 'ERROR';
        //If user record Exists change the user access
        try {
            $setParams = $this->setParams($data);
            $sql = "UPDATE `user` SET " . $setParams . " WHERE userID = :userID";
            $stmt = $this->PDOObj->prepare($sql);
            $this->bindParams($stmt, $data);
            $record = $stmt->execute();

            if ($record === TRUE) {
                $response['status'] = 'SUCCESS';
                $response['message'] = 'Record Updated';
            }
        } catch (PDOException $e) {
            $response['message'] = $e->getMessage();
        }

        return $response;
    }

    /**
     * Create Set params
     * @param type $data
     * @return string
     */
    private function setParams($data) {
        unset($data['userID']);
        $setParams = "";

        foreach ($data as $name => $value) {
            $setParams .= ' ' . $name . ' = :' . $name . ',';
        }
        $params = substr($setParams, 0, -1);
        return $params;
    }

    /**
     * Create Bind params
     * @param type $stmt
     * @param type $data
     * @param type $action
     */
    private function bindParams($stmt, $data) {
        foreach ($data as $field => $val) {
            if (is_int($val)) {
                $stmt->bindValue(':' . $field, $val, PDO::PARAM_INT);
            } else if (is_string($val)) {
                $stmt->bindValue(':' . $field, $val, PDO::PARAM_STR);
            }
        }
    }

}
