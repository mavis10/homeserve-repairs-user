<?php

require('UserDataClass.php');
$userDataClass = new UserDataClass(); // create Object for user data class

$response = array();
$response['status'] = 'SUCCESS';


//check if page has POST data and action assigned 
if (!empty($_POST) && isset($_POST['action'])) {
    $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_SPECIAL_CHARS, FILTER_SANITIZE_STRING);

    //Performs the CRUD actions for user depend on action assigned
    switch ($action) {

        case "addNewUser":
            //Filter the POST values
            $data = [
                'firstName' => filter_input(INPUT_POST, 'firstName', FILTER_SANITIZE_SPECIAL_CHARS, FILTER_SANITIZE_STRING),
                'lastName' => filter_input(INPUT_POST, 'lastName', FILTER_SANITIZE_SPECIAL_CHARS, FILTER_SANITIZE_STRING),
                'email' => filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL),
                'userName' => filter_input(INPUT_POST, 'userName', FILTER_SANITIZE_SPECIAL_CHARS, FILTER_SANITIZE_STRING),
                'password' => password_hash(filter_input(INPUT_POST, 'password', FILTER_SANITIZE_SPECIAL_CHARS, FILTER_SANITIZE_STRING), PASSWORD_DEFAULT)
            ];
            //Add user data and read the response
            $response = $userDataClass->addUser($data);

            break;


        case "updateAccess":
            //Prepare the data array with filtering the POST values
            $data = [
                'userID' => filter_input(INPUT_POST, "userID", FILTER_VALIDATE_INT),
            ];

            $userRecord = $userDataClass->readUser($data, 'userID');
             if($userRecord)
             {
                $data['access'] = ($userRecord->access==="ACTIVE")?"INACTIVE":"ACTIVE";
                //update user record for given user access
                $response = $userDataClass->updateUser($data);
             }
             else
             {
                $response['status'] = 'ERROR';
                $response['message'] = "Error encountered while performing this action.";
             }
            break;

        case "updateUser":
            break;
        
        case "edit":

            break;
        case "delete":

            break;
    }
}

$response['data'] = $userDataClass->readAllUsers();
//send JSON encoded response message 
echo json_encode($response);




