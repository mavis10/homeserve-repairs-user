<?php
include('user/userView.php');
?>